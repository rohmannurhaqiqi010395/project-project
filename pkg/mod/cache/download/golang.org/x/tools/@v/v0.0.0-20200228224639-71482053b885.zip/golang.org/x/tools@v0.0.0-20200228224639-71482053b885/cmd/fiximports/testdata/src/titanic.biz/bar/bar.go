// This package is moving to new.com too.
package bar // import "new.com/bar"
