package banana

import (
	_ "old.com/one"
	_ "titanic.biz/bar"
	_ "titanic.biz/foo"
)
